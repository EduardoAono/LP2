﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; /* globais */
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox1.Text, out raio) || (raio <= 0))
            { MessageBox.Show("Raio inválido!"); }

        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            if (!double.TryParse(textBox1.Text,out raio) || (raio <= 0))
            {
                MessageBox.Show("raio inválida");
                textBox1.Focus();
            }
            else if (!Double.TryParse(textBox2.Text,out altura)|| (altura <= 0))
            {
                MessageBox.Show("altura inválida!");
                textBox2.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2)* altura;
                textBox3.Text = volume.ToString("N2");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = String.Empty;
            textBox3.Clear();
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox2.Text, out altura) || (altura <= 0))
            { MessageBox.Show("Altura inválido!"); }
        }


            private void TextBox3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox3.Text, out volume) || (volume <= 0))
            { MessageBox.Show("Altura inválido!"); }
        }
         
        }
    }
