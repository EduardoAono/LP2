﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] entradas = new string[2, 4];

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                 


                    entradas[i,j]= Interaction.InputBox($"Total Entradas do Produto : {i + 1} Semana : {j + 1}");
                    
                    lBoxEntrada.Items.Add($"Total Entradas do Produto {i + 1} Semana {j + 1}");


                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lBoxEntrada.Items.Clear();
        }
    }
}