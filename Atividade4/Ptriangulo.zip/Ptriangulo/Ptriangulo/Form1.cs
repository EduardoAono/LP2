﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        Double A;
        Double B;
        Double C;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(TextA.Text, out A) || (A <= 0))
            {
                MessageBox.Show("Numero Invalido!");
                TextA.Focus();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TextB_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(TextB.Text, out B) || (B <= 0))
            {
                MessageBox.Show("Numero Invalido!");
                TextB.Focus();
            }
        }

        private void TextC_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse (TextC.Text , out C ) || (C <= 0))
            {
                MessageBox.Show("Numero Invalido!");
                TextC.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (A == B == C)
            {
                MessageBox.Show("Triângulo Equilatero");
           

            }
            else
                if ((A == B) || (B == C))
                    {
                MessageBox.Show("Triângulo Isóceles");
            }
            else
                if (A != B != C)
            {
                MessageBox.Show("Triângulo Escaleno");
            }
            else
                if ((Math.Abs(B - C) < A < B + C) || (Math.Abs(A - C) < B < A + C) || (Math.Abs(A - B) < C < A + B))
            {
                MessageBox.Show("Não Forma Triângulo!");
            }
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            TextA.Clear();
            TextB.Clear();
            TextC.Clear();
        }

        private void bntClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
