﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
           
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox1.Text, out numero1))
            {
                MessageBox.Show("Número Inválido!");
                    textBox1.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            textBox3.Text = resultado.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            textBox3.Text = resultado.ToString();   
        }

        private void button3_Click(object sender, EventArgs e)
        {
            resultado= numero1 * numero2;
            textBox3.Text = resultado.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            resultado= numero1/ numero2;
            textBox3.Text = resultado.ToString();
            if (numero2 == 0)
            {
                MessageBox.Show("divisão por 0 inválida ");
                textBox1.Focus();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();   
            textBox3.Clear();

        }

        private void Form1_BackColorChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();    
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox2.Text, out numero2))
            {
                MessageBox.Show("Número Inválido!");
                textBox2.Focus();
            }
        }
    }
}
